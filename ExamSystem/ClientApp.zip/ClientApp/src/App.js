import React, { Component } from 'react';
import { Route, Routes } from 'react-router-dom';
import { Layout } from './components/Layout';
import './custom.css';
import Register from './components/Register';

export default class App extends Component {
  static displayName = App.name;

  render() {
    return (
      <Layout>
        <Routes>
          <Route path='/' element={<Layout/>}>
            <Route path='register' element={<Register />}/>
          </Route>
        </Routes>
      </Layout>
    );
  }
}
